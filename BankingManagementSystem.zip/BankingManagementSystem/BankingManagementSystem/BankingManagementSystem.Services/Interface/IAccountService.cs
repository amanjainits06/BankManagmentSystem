﻿using BankingManagementSystem.Domain.DTO;
using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Services.Interface
{
  public interface IAccountService
  {
    Task<AccountDetail> CreateAccountAsync(AccountDetail accountDTO, CancellationToken cancellationToken);
    Task<AccountDetail> GetAccountAsync(long accountNumber, CancellationToken cancellationToken);
    Task<bool> DeleteAccountAsync(long accountNumber, CancellationToken cancellationToken);
    Task<bool> DepositAsync(long accountNumber, double amount, CancellationToken cancellationToken);
    Task<bool> WithdrawAsync(long accountNumber, double amount, CancellationToken cancellationToken);
  }
}
