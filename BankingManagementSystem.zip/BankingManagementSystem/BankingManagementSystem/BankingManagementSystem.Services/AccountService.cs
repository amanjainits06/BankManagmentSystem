﻿using AutoMapper;
using BankingManagementSystem.Domain.DTO;
using BankingManagementSystem.Domain.Models;
using BankingManagementSystem.Infrastructure.Interface;
using BankingManagementSystem.Services.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Services
{
  public class AccountService : IAccountService
  {
    private readonly IAccountRepository _accountRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    public AccountService(IUnitOfWork unitOfWork, IAccountRepository accountRepository, IMapper mapper)
    {
      this._accountRepository = accountRepository;
      this._unitOfWork = unitOfWork;
      this._mapper = mapper;
    }

    /// <summary>
    /// Create a new account based on the provided account details.
    /// </summary>
    /// <param name="accountDTO">The account details to create an account.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>The newly created account details.</returns>
    /// <exception cref="InvalidOperationException">Thrown if account details are not provided.</exception>

    public async Task<AccountDetail> CreateAccountAsync(AccountDetail accountDTO, CancellationToken cancellationToken)
    {
      if (accountDTO != null)
      {
        var account = _mapper.Map<Account>(accountDTO);
        var createdAccount = await _accountRepository.CreateAccountAsync(account, cancellationToken).ConfigureAwait(false);
        await _unitOfWork.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
        return _mapper.Map<AccountDetail>(createdAccount);
      }
      throw new InvalidOperationException("Account details not provided.");
    }

    /// <summary>
    /// Get account details for a specific account based on its account number.
    /// </summary>
    /// <param name="accountNumber">The account number to retrieve.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>The account details if found; otherwise, null.</returns>
    public async Task<AccountDetail> GetAccountAsync(long accountNumber, CancellationToken cancellationToken)
    {
      var account = await _accountRepository.GetAcccountDetailsAsync(accountNumber, cancellationToken).ConfigureAwait(false);
      if (account != null)
      {
        return _mapper.Map<AccountDetail>(account);
      }
      return null;
    }

    /// <summary>
    /// Delete an account with a specific account number.
    /// </summary>
    /// <param name="accountNumber">The account number to delete.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>True if the account was successfully deleted; otherwise, false.</returns>

    public async Task<bool> DeleteAccountAsync(long accountNumber, CancellationToken cancellationToken)
    {
      var account = await _accountRepository.GetAcccountDetailsAsync(accountNumber, cancellationToken).ConfigureAwait(false);

      if (account != null)
      {
        var result = await _accountRepository.DeleteAccountAsync(accountNumber, cancellationToken).ConfigureAwait(false);
        await _unitOfWork.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
        return result;
      }
      return false;
    }

    /// <summary>
    /// Deposit funds into an account.
    /// </summary>
    /// <param name="accountNumber">The account number to deposit funds into.</param>
    /// <param name="amount">The amount to deposit.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>True if the deposit was successful; otherwise, an exception may be thrown.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the deposit amount exceeds the maximum limit or the account is not found.</exception>

    public async Task<bool> DepositAsync(long accountNumber, double amount, CancellationToken cancellationToken)
    {
      var account = await _accountRepository.GetAcccountDetailsAsync(accountNumber, cancellationToken).ConfigureAwait(false);

      if (account != null)
      {
        if (amount <= 10000)
        {
          account.Balance += amount;
          var result = await _accountRepository.UpdateAccountBalanceAsync(accountNumber, account.Balance, cancellationToken).ConfigureAwait(false);
          await _unitOfWork.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
          return result;
        }
        throw new InvalidOperationException("Deposit amount exceeds the maximum limit.");
      }
      throw new InvalidOperationException("Account not found.");
    }

    /// <summary>
    /// Withdraw funds from an account.
    /// </summary>
    /// <param name="accountNumber">The account number to withdraw funds from.</param>
    /// <param name="amount">The amount to withdraw.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>True if the withdrawal was successful; otherwise, an exception may be thrown.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the withdrawal amount exceeds the maximum limit, there are insufficient funds, or the account is not found.</exception>

    public async Task<bool> WithdrawAsync(long accountNumber, double amount, CancellationToken cancellationToken)
    {
      var account = await _accountRepository.GetAcccountDetailsAsync(accountNumber, cancellationToken).ConfigureAwait(false);

      if (account != null)
      {
        if (amount > 0.9 * account.Balance)
        {
          throw new InvalidOperationException("You cannot withdraw more than 90 % of their total balance from an account in a single transaction");
        }

        if (account.Balance - amount >= 100)
        {
          account.Balance -= amount;

          var result = await _accountRepository.UpdateAccountBalanceAsync(accountNumber, account.Balance, cancellationToken).ConfigureAwait(false);
          await _unitOfWork.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
          return result;
        }
        throw new InvalidOperationException("Insufficient funds or withdrawal amount too high.");
      }
      throw new InvalidOperationException("Account not found.");
    }
  }
}
