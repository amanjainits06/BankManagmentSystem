﻿using BankingManagementSystem.Domain.DTO;
using FluentValidation;

namespace BankingManagementSystem.Domain.Validators
{
  public class UserDetailValidator : AbstractValidator<UserDetail>
  {
    public UserDetailValidator()
    {
      When(user => user.UserId <= 0, () =>
      {
        RuleFor(user => user.Name).NotEmpty().WithMessage("Name is required.");
        RuleFor(user => user.Email).NotEmpty().WithMessage("Email is required.");
        RuleFor(user => user.Email).EmailAddress().WithMessage("Invalid Email Address.");
        RuleFor(user => user.Password).NotEmpty().WithMessage("Password is required.");
        RuleFor(user => user.Address).NotEmpty().WithMessage("Address is required.");
      });
    }
  }
}
