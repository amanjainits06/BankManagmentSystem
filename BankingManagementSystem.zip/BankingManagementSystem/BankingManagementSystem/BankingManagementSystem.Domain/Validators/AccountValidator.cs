﻿using BankingManagementSystem.Domain.DTO;
using FluentValidation;

namespace BankingManagementSystem.Domain.Validators
{
  public class AccountDetailValidator : AbstractValidator<AccountDetail>
  {
    public AccountDetailValidator()
    {
      RuleFor(account => account.User).SetValidator(new UserDetailValidator());
      RuleFor(account => account.Type).IsInEnum().WithMessage("Invalid Account Type.");
      RuleFor(account => account.Balance).GreaterThanOrEqualTo(100).WithMessage("Balance cannot be less than $100.");

      // Validate that the User property is not null
      RuleFor(account => account.User)
          .NotNull()
          .WithMessage("User information is required.")
          .SetValidator(new UserDetailValidator());
    }
  }
}
