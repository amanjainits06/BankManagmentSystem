﻿using AutoMapper;
using BankingManagementSystem.Domain.DTO;
using BankingManagementSystem.Domain.Models;

namespace BankingManagementSystem.Domain.Mapping
{
  public class UserMappingProfile : Profile
  {
    public UserMappingProfile()
    {
      CreateMap<User, UserDetail>()
          .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.UserId))
          .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
          .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
          .ForMember(dest => dest.Password, opt => opt.Ignore()) // Ignore Password for UserDTO
          .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.Address));

      CreateMap<UserDetail, User>()
          .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.UserId))
          .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
          .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
          .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.Password)) // Map Password for User
          .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.Address));
    }
  }
}
