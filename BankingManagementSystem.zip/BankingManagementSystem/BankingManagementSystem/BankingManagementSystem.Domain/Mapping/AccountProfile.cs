﻿using AutoMapper;
using BankingManagementSystem.Domain.DTO;
using BankingManagementSystem.Domain.Models;

namespace BankingManagementSystem.Domain.Mapping
{
  public class AccountProfile:Profile
  {
    public AccountProfile()
    {
      CreateMap<Account, AccountDetail>()
          .ForMember(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.AccountNumber))
          .ForMember(dest => dest.User, opt => opt.MapFrom(src => src.User))
          .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
          .ForMember(dest => dest.Balance, opt => opt.MapFrom(src => src.Balance));

      CreateMap<AccountDetail, Account>()
          .ForMember(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.AccountNumber))
          .ForMember(dest => dest.User, opt => opt.MapFrom(src => src.User))
          .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
          .ForMember(dest => dest.Balance, opt => opt.MapFrom(src => src.Balance));
    }
  }
}
