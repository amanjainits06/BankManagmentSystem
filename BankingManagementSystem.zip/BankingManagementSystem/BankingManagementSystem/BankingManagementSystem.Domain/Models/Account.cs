﻿using BankingManagementSystem.Domain.Enum;
using System;

namespace BankingManagementSystem.Domain.Models
{
  public class Account
  {
    public User User { get; set; }
    public long AccountNumber { get; set; } 
    public long UserId 
    {
      get
      {
        if (User != null)
        {
          return User.UserId;
        }
        else
        {
          return default;
        }
      }
    }
    public AccountType Type { get; set; }
    public double Balance { get; set; }
    public DateTime OpeningDate { get; set; }
    public DateTime ClosingDate { get; set; }
    public DateTime CreatedOn { get; set;}
    public DateTime UpdatedOn { get; set;}
  }
}
