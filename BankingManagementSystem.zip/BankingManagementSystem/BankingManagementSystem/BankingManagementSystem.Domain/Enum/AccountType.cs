﻿using System.ComponentModel.DataAnnotations;

namespace BankingManagementSystem.Domain.Enum
{
  public enum AccountType
  { 
    Saving,
    Current
  }
}
