﻿using BankingManagementSystem.Domain.Enum;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace BankingManagementSystem.Domain.DTO
{
  public class AccountDetail
  {
    [Description("The account number.")]
    public long AccountNumber { get; set; }

    [Required]
    [Description("User details.")]
    public UserDetail User { get; set; }

    [Required]
    [Description("Account type (Saving or Current).")]
    public AccountType Type { get; set; }

    [Required]
    [Description("Account balance.")]
    public double Balance { get; set; }
  }
}
