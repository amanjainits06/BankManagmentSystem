﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BankingManagementSystem.Domain.DTO
{
  public class UserDetail
  {
    [Required]
    [Description("The unique user ID.")]
    public long UserId { get; set; }

    [Required]
    [StringLength(10, MinimumLength = 3)]
    [Description("The user's name.")]
    public string Name { get; set; }

    [Required]
    [EmailAddress]
    [Description("The user's email address.")]
    public string Email { get; set; }

    [Required]
    [MinLength(8)]
    [DataType(DataType.Password)]
    [Description("The user's password.")]
    public string Password { get; set; }

    [Required]
    [Description("The user's address.")]
    public string Address { get; set; }
  }
}
