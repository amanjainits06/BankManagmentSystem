using BankingManagementSystem.API.Controllers;
using BankingManagementSystem.Domain.DTO;
using BankingManagementSystem.Domain.Enum;
using BankingManagementSystem.Services.Interface;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace BankingManagementSystem.API.Test
{
  public class AccountControllerTests
  {

    [Fact]
    public async Task CreateAccountAsync_InvalidInput_ReturnsBadRequest()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);

      // Act
      var result = await controller.CreateAccountAsync(null);

      // Assert
      Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task GetAccountAsync_ExistingAccount_ReturnsOk()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 123; // Existing account

      accountServiceMock.Setup(service => service.GetAccountAsync(accountNumber, It.IsAny<CancellationToken>()))
          .ReturnsAsync(new AccountDetail
          {
            AccountNumber = accountNumber,
            User = new UserDetail
            {
              UserId = 456,
              Name = "Pawan jain",
              Email = "Pawan@example.com",
              Password = "password123",
              Address = "123 Delhi",
            },
            Type = AccountType.Saving,
            Balance = 1000.0
          });

      // Act
      var result = await controller.GetAccountAsync(accountNumber);

      // Assert
      var okResult = Assert.IsType<OkObjectResult>(result);
      var account = Assert.IsType<AccountDetail>(okResult.Value);
      Assert.Equal(accountNumber, account.AccountNumber);
    }

    [Fact]
    public async Task GetAccountAsync_NonExistingAccount_ReturnsNotFound()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 456; // Non-existing account

      accountServiceMock.Setup(service => service.GetAccountAsync(accountNumber, It.IsAny<CancellationToken>()))
          .ReturnsAsync((AccountDetail)null);

      // Act
      var result = await controller.GetAccountAsync(accountNumber);

      // Assert
      Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task DeleteAccountAsync_ExistingAccount_ReturnsOk()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 123; // Existing account

      accountServiceMock.Setup(service => service.DeleteAccountAsync(accountNumber, It.IsAny<CancellationToken>()))
          .ReturnsAsync(true);

      // Act
      var result = await controller.DeleteAccountAsync(accountNumber);

      // Assert
      var okResult = Assert.IsType<OkObjectResult>(result);
      Assert.Equal("Account Deleted Successfully", okResult.Value);
    }

    [Fact]
    public async Task DeleteAccountAsync_NonExistingAccount_ReturnsNotFound()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 456; // Non-existing account

      accountServiceMock.Setup(service => service.DeleteAccountAsync(accountNumber, It.IsAny<CancellationToken>()))
          .ReturnsAsync(false);

      // Act
      var result = await controller.DeleteAccountAsync(accountNumber);

      // Assert
      Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task DepositAsync_ValidInput_ReturnsOk()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 123; // Existing account
      var amount = 500.0;

      accountServiceMock.Setup(service => service.DepositAsync(accountNumber, amount, It.IsAny<CancellationToken>()))
          .ReturnsAsync(true);

      // Act
      var result = await controller.DepositAsync(accountNumber, amount);

      // Assert
      var okResult = Assert.IsType<OkObjectResult>(result);
      Assert.Equal("Deposit successful.", okResult.Value);
    }

    [Fact]
    public async Task DepositAsync_InvalidAccount_ReturnsBadRequest()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 456; // Non-existing account
      var amount = 500.0;

      accountServiceMock.Setup(service => service.DepositAsync(accountNumber, amount, It.IsAny<CancellationToken>()))
          .ReturnsAsync(false);

      // Act
      var result = await controller.DepositAsync(accountNumber, amount);

      // Assert
      Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task WithdrawAsync_ValidInput_ReturnsOk()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 123; // Existing account
      var amount = 500.0;

      accountServiceMock.Setup(service => service.WithdrawAsync(accountNumber, amount, It.IsAny<CancellationToken>()))
          .ReturnsAsync(true);

      // Act
      var result = await controller.WithdrawAsync(accountNumber, amount);

      // Assert
      var okResult = Assert.IsType<OkObjectResult>(result);
      Assert.Equal("Withdrawal successful.", okResult.Value);
    }

    [Fact]
    public async Task WithdrawAsync_InvalidAccount_ReturnsBadRequest()
    {
      // Arrange
      var accountServiceMock = new Mock<IAccountService>();
      var serviceProviderMock = new Mock<IServiceProvider>();
      var controller = new AccountController(accountServiceMock.Object, null, serviceProviderMock.Object);
      var accountNumber = 456; // Non-existing account
      var amount = 500.0;

      accountServiceMock.Setup(service => service.WithdrawAsync(accountNumber, amount, It.IsAny<CancellationToken>()))
          .ReturnsAsync(false);

      // Act
      var result = await controller.WithdrawAsync(accountNumber, amount);

      // Assert
      Assert.IsType<BadRequestObjectResult>(result);
    }
  }
}
