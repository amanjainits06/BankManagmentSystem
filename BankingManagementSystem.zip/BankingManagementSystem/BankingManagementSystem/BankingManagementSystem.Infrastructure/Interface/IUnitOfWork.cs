﻿using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Infrastructure.Interface
{
  public interface IUnitOfWork
  {
    BankingDbContext DbContext { get; }
    Task SaveChangesAsync(CancellationToken cancellationToken);
  }
}
