﻿using BankingManagementSystem.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Infrastructure.Interface
{
  public interface IAccountRepository
  {
    Task<Account> GetAcccountDetailsAsync(long accountNumber, CancellationToken cancellationToken);

    Task<Account> CreateAccountAsync(Account account, CancellationToken cancellationToken);
    Task<bool> DeleteAccountAsync(long accountNumber, CancellationToken cancellationToken);
    Task<bool> UpdateAccountBalanceAsync(long accountNumber, double newBalance, CancellationToken cancellationToken);
  }
}
