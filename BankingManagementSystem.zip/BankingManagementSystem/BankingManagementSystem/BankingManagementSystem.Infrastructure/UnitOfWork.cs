﻿using BankingManagementSystem.Infrastructure.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Infrastructure
{
  public class UnitOfWork : IUnitOfWork
  {
    private readonly BankingDbContext _context;
    public UnitOfWork(BankingDbContext context)
    {
      this._context = context;
    }

    BankingDbContext IUnitOfWork.DbContext
    {
      get
      {
        return this._context;
      }
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
      return this._context.SaveChangesAsync(cancellationToken);
    }
  }
}
