﻿using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Infrastructure
{
  public class BankingDbContext
  {
    public BankingDbContext() { }

    // Demo purpose only
    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
      // Save into DB,I keep empty implementation
      return Task.FromResult(0);
    }
  }
}
