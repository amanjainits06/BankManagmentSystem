﻿using BankingManagementSystem.Domain.Models;
using BankingManagementSystem.Infrastructure.Interface;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.Infrastructure
{
  public class AccountRepository : IAccountRepository
  {
    // Demo purpose only, as of now we are doing in memory
    private readonly BankingDbContext context;
    private readonly ILogger<AccountRepository> _logger;

    public AccountRepository(BankingDbContext context, ILogger<AccountRepository> logger)
    {
      this.context = context;
      this._logger = logger;
    }

    public Task<Account> CreateAccountAsync(Account account, CancellationToken cancellationToken)
    {
      User inMemoryUser;
      if(account.User.UserId <=0)
      {
        InMemoryCollection.CurrentUserId++;
        account.User.UserId = default;
        account.User.UpdatedOn = DateTime.UtcNow;
        account.User.CreatedOn = DateTime.UtcNow;
        account.User.UserId = InMemoryCollection.CurrentUserId;
        InMemoryCollection.Users.Add(account.User);
        inMemoryUser = account.User;
      }
      else
      {
        inMemoryUser = InMemoryCollection.Users.Find(u => u.UserId == account.User.UserId);
        if (inMemoryUser == null)
        {
          throw new InvalidOperationException("Provided User is not registered with us.");
        }
      }

      InMemoryCollection.CurrentAccountId++;
      account.User = inMemoryUser;
      account.AccountNumber = default;
      account.UpdatedOn = DateTime.UtcNow;
      account.CreatedOn = DateTime.UtcNow;
      account.AccountNumber = InMemoryCollection.CurrentAccountId;
      InMemoryCollection.Accounts.Add(account);
      _logger.LogInformation(string.Format($"Account created successfully -{0}", account.AccountNumber));
      return Task.FromResult(account);
    }

    public Task<bool> DeleteAccountAsync(long accountNumber, CancellationToken cancellationToken)
    {
      var inMemoryAccount = InMemoryCollection.Accounts.Find(u => u.AccountNumber == accountNumber);
      var result = InMemoryCollection.Accounts.Remove(inMemoryAccount);
      _logger.LogInformation(string.Format($"Account deleted successfully -{0}", accountNumber));
      return Task.FromResult(result);
    }

    public Task<Account> GetAcccountDetailsAsync(long accountNumber, CancellationToken cancellationToken)
    {
      return Task.FromResult(InMemoryCollection.Accounts.Find(u => u.AccountNumber == accountNumber));
    }

    public Task<bool> UpdateAccountBalanceAsync(long accountNumber, double newBalance, CancellationToken cancellationToken)
    {
      var account = InMemoryCollection.Accounts.Find(a => a.AccountNumber == accountNumber);
      account.Balance = newBalance;
      _logger.LogInformation(string.Format($"Balance updated for account -{0}", accountNumber));
      return Task.FromResult(true);
    }
  }
}
