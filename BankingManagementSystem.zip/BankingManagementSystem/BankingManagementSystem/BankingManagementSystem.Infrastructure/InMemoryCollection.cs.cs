﻿using BankingManagementSystem.Domain.Models;
using System.Collections.Generic;

namespace BankingManagementSystem.Infrastructure
{
  public static class InMemoryCollection
  {
    public static long CurrentUserId;
    public static long CurrentAccountId;
    public static List<Account> Accounts = new List<Account>();
    public static List <User> Users = new List<User>();
  }
}
