using BankingManagementSystem.Domain.DTO;
using BankingManagementSystem.Domain.Mapping;
using BankingManagementSystem.Domain.Validators;
using BankingManagementSystem.Infrastructure;
using BankingManagementSystem.Infrastructure.Interface;
using BankingManagementSystem.Services;
using BankingManagementSystem.Services.Interface;
using FluentValidation;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace BankingManagementSystem
{
  public class Startup
  {
    public Startup(IConfiguration configuration)
    {
      Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
      services.AddSwaggerGen(c =>
      {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "BankingManagementSystem.API", Version = "v1", Description = "Banking Management System" });
      })
      .AddSingleton<IAccountService, AccountService>()
      .AddSingleton<IAccountRepository, AccountRepository>()
      .AddSingleton<IUnitOfWork, UnitOfWork>()
      .AddSingleton<BankingDbContext>()
      .AddScoped<IValidator<AccountDetail>, AccountDetailValidator>()
      .AddScoped<IValidator<UserDetail>, UserDetailValidator>()
      .AddAutoMapper(typeof(AccountProfile), typeof(UserMappingProfile))
      .AddControllers();
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
      if (env.IsDevelopment())
      {
        app.UseSwaggerUI();
        app.UseSwagger();

      }

      app.UseRouting();

      app.UseAuthorization();

      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
      });
    }
  }
}
