﻿using BankingManagementSystem.Domain.DTO;
using BankingManagementSystem.Services.Interface;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BankingManagementSystem.API.Controllers
{
  [Route("api/accounts")]
  [ApiController]
  public class AccountController : ControllerBase
  {
    private readonly IAccountService _accountService;
    private readonly ILogger<AccountController> _logger;
    private readonly IServiceProvider _serviceProvider;
    private delegate Task<IActionResult> RequestHandler(CancellationToken cancellationToken, string customErrorMessage = null);

    public AccountController(IAccountService _accountService, ILogger<AccountController> logger, IServiceProvider serviceProvider)
    {
      this._accountService = _accountService;
      this._serviceProvider = serviceProvider;
      this._logger = logger;
    }

    [HttpPost("/createaccount")]
    public Task<IActionResult> CreateAccountAsync([FromBody] AccountDetail accountDTO)
    {
      return HandleRequestAsync(async (cancellationToken, customErrorMessage) =>
      {
        if (accountDTO == null)
        {
          return BadRequest("Account Details are missing");
        }

        var validator = _serviceProvider.GetRequiredService<IValidator<AccountDetail>>();
        var valResult = await validator.ValidateAsync(accountDTO, cancellationToken).ConfigureAwait(false);

        if (!valResult.IsValid)
        {
          var errors = valResult.Errors.Select(error => error.ErrorMessage);
          return BadRequest(new { Errors = errors });
        }

        var newAccount = await this._accountService.CreateAccountAsync(accountDTO, cancellationToken).ConfigureAwait(false);

        return Ok(newAccount);
      }, "Error while creating Account");
    }

    [HttpGet("{accountNumber}")]
    public Task<IActionResult> GetAccountAsync(long accountNumber)
    {
      return HandleRequestAsync(async (cancellationToken, customErrorMessage) =>
      {
        if (accountNumber <= 0)
        {
          return BadRequest("Please provide valid account number");
        }

        var account = await _accountService.GetAccountAsync(accountNumber, cancellationToken).ConfigureAwait(false);

        if (account != null)
          return Ok(account);

        return NotFound("Account not found.");
      }, string.Format($"An error occurred while fetching Account details for {0}", accountNumber));
    }


    [HttpDelete("{accountNumber}")]
    public Task<IActionResult> DeleteAccountAsync(long accountNumber)
    {
      return HandleRequestAsync(async (cancellationToken, customErrorMessage) =>
      {
        if (accountNumber <= 0)
        {
          return BadRequest("Please provide valid account number");
        }

        var success = await _accountService.DeleteAccountAsync(accountNumber, cancellationToken).ConfigureAwait(false);
        if (success)
        {
          return this.Ok("Account Deleted Successfully");
        }
        return NotFound("Account not found.");
      }, string.Format($"An error occurred while Deleting Account details for {0}", accountNumber));
    }

    [HttpPost("{accountNumber}/deposit")]
    public Task<IActionResult> DepositAsync(long accountNumber, [FromBody] double amount)
    {
      return HandleRequestAsync(async (cancellationToken, customErrorMessage) =>
      {
        if (accountNumber <= 0)
        {
          return BadRequest("Please provide valid account number");
        }

        if (amount <= 0)
        {
          return BadRequest("Amount must be more then zero");
        }

        var success = await _accountService.DepositAsync(accountNumber, amount, cancellationToken).ConfigureAwait(false);
        if (success)
        {
          return Ok("Deposit successful.");
        }
        return BadRequest("Deposit failed.");
      }, string.Format($"An error occurred while Depositing amount in Account {0}", accountNumber));
    }

    [HttpPost("{accountNumber}/withdraw")]
    public Task<IActionResult> WithdrawAsync(long accountNumber, [FromBody] double amount)
    {
      return HandleRequestAsync(async (cancellationToken, customErrorMessage) =>
      {
        if (accountNumber <= 0)
        {
          return BadRequest("Please provide valid account number");
        }

        if (amount <= 0)
        {
          return BadRequest("Amount must be more then zero");
        }

        var success = await _accountService.WithdrawAsync(accountNumber, amount, cancellationToken).ConfigureAwait(false);
        if (success)
        {
          return Ok("Withdrawal successful.");
        }
        return BadRequest("Withdrawal failed.");
      }, string.Format($"An error occurred while withdraw amount from Account {0}", accountNumber));
    }

    private async Task<IActionResult> HandleRequestAsync(RequestHandler handler, string customErrorMessage = null)
    {
      try
      {
        // Create a CancellationTokenSource with a 60-second timeout
        var cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(60));
        CancellationToken cancellationToken = cancellationTokenSource.Token;

        return await handler(cancellationToken, customErrorMessage);
      }
      catch (InvalidOperationException ex)
      {
        return BadRequest(ex.Message);
      }
      catch (Exception ex)
      {
        // Log the exception 
        var logMessage = $"An error occurred: {customErrorMessage ?? "An error occurred."} Exception: {ex.Message}";
        _logger.LogError(logMessage);
        return StatusCode(StatusCodes.Status500InternalServerError, customErrorMessage ?? "An error occurred.");
      }
    }
  }
}

